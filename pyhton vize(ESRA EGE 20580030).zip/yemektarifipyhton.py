class Yemek_Tarifi:
  def __init__(Tarifler, adi,malzeme,yapilis):
    Tarifler.adi = adi
    Tarifler.malzeme = malzeme
    Tarifler.yapilis = yapilis

  def veriGoster(veri):
    print("Yapılan Yemeğin Adı : " + veri.adi)
    print("Malzemeler : " + veri.malzeme)
    print("Tarif : " + veri.yapilis)

print("**********Yemek Tarifi Uygulaması**************")

adi=input("Lütfen yemeğin adını girin : ")
malzemeler = input("Malzemeler : ")
yapilisi = input("Nasıl Yapılıyor? : ")


print("**********************************************")
print("**********************************************")

tarif1 = Yemek_Tarifi(adi,malzemeler,yapilisi)

tarif1.veriGoster()

